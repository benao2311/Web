import asyncio, hashlib, hmac, json, logging, os, re, shutil, sqlite3, subprocess, threading, time, uuid
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager
from pathlib import Path
from urllib.parse import urlparse, unquote
from fastapi import FastAPI, Request, HTTPException, Depends
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field, model_validator
from selection import choose

DATA=Path(os.getenv('DATA_DIR','data')).resolve();DATA.mkdir(parents=True,exist_ok=True)
KEY=os.getenv('PROCESSOR_API_KEY',''); DB=DATA/'jobs.sqlite'; QUEUE=ThreadPoolExecutor(max_workers=1)
LOCK=threading.RLock(); STOP={}; PROCESSES={}; MODEL=None
MAX_UPLOAD=80*1024**2; MAX_DISK=int(os.getenv('MAX_DISK_GB','20'))*1024**3
MAX_SECONDS=int(os.getenv('MAX_VIDEO_SECONDS','7200'))
TERMINAL={'done','error','cancelled'}
log=logging.getLogger('clip-propio')

class Settings(BaseModel):
    url:str=''
    mode:str='video'
    count:int=Field(5,ge=1,le=20)
    min_seconds:int=Field(30,ge=15,le=90)
    max_seconds:int=Field(75,ge=20,le=120)
    live_minutes:int=Field(15,ge=5,le=60)
    language:str='es'
    context:str=Field('',max_length=160)
    fit:str='cover'
    @model_validator(mode='after')
    def validate_values(self):
        if self.max_seconds<self.min_seconds:raise ValueError('La duración máxima debe superar a la mínima.')
        if self.mode not in ('video','live') or self.language not in ('es','en','auto') or self.fit not in ('cover','contain'):raise ValueError('Configuración no válida.')
        return self

def connect():
    c=sqlite3.connect(DB,timeout=30);c.row_factory=sqlite3.Row;return c

def initialize():
    with connect() as c:
        c.execute('CREATE TABLE IF NOT EXISTS jobs (id TEXT PRIMARY KEY, owner TEXT NOT NULL, state TEXT NOT NULL, message TEXT NOT NULL, settings TEXT NOT NULL, clips TEXT NOT NULL, created REAL NOT NULL)')
        c.execute("UPDATE jobs SET state='error',message='El servidor se reinició. Crea una nueva tarea; los clips completados se conservan.' WHERE state NOT IN ('done','error','cancelled')")

def record(job):
    with connect() as c:r=c.execute('SELECT * FROM jobs WHERE id=?',(job,)).fetchone()
    if not r:raise HTTPException(404,'Tarea no encontrada.')
    return dict(r)

def update(job,**values):
    if not values:return
    with connect() as c:c.execute('UPDATE jobs SET '+','.join(k+'=?' for k in values)+' WHERE id=?',(*values.values(),job))

def expose(row):
    return {k:(json.loads(row[k]) if k in ('settings','clips') else row[k]) for k in ('id','state','message','settings','clips','created')}

def disk_check():
    used=sum(p.stat().st_size for p in DATA.rglob('*') if p.is_file())
    if used>MAX_DISK:raise HTTPException(507,'El almacenamiento del servidor está lleno. Elimina tareas terminadas para liberar espacio.')

def auth(req:Request):
    if not KEY or not hmac.compare_digest(req.headers.get('Authorization',''),'Bearer '+KEY):raise HTTPException(401,'Acceso no autorizado.')
    owner=req.headers.get('X-Clip-Owner','')
    if not owner or len(owner)>300:raise HTTPException(401,'Falta la identidad del usuario.')
    return hashlib.sha256(owner.encode()).hexdigest()

def owned(job,owner):
    row=record(job)
    if row['owner']!=owner:raise HTTPException(404,'Tarea no encontrada.')
    return row

def validate_url(raw):
    u=urlparse(raw.strip());host=(u.hostname or '').lower()
    allowed=('youtube.com','youtu.be','twitch.tv','facebook.com','fb.watch','tiktok.com')
    if u.scheme!='https' or u.username or u.password or u.port not in (None,443) or not any(host==d or host.endswith('.'+d) for d in allowed):raise ValueError('Usa un enlace HTTPS de YouTube, Twitch, Facebook o TikTok.')
    return raw.strip()

def new_job(owner,settings):
    with LOCK:
        with connect() as c:
            active=c.execute("SELECT count(*) FROM jobs WHERE state NOT IN ('done','error','cancelled')").fetchone()[0]
            if active>=3:raise HTTPException(429,'Hay tres tareas activas. Espera a que termine una.')
            disk_check();job=uuid.uuid4().hex
            (DATA/job).mkdir()
            c.execute('INSERT INTO jobs VALUES(?,?,?,?,?,?,?)',(job,owner,'queued','En cola',settings.model_dump_json(),'[]',time.time()))
        STOP[job]=threading.Event()
        return job

def check(job):
    if STOP.get(job) and STOP[job].is_set():raise InterruptedError('Tarea detenida.')

def execute(job,args,cwd=None):
    check(job)
    # stderr on disk avoids blocking a long media conversion on a pipe buffer.
    err=DATA/job/'ffmpeg.log'
    with err.open('wb') as f:
        p=subprocess.Popen(args,cwd=cwd,stdout=subprocess.DEVNULL,stderr=f)
        with LOCK:PROCESSES.setdefault(job,set()).add(p)
        try:
            while p.poll() is None:
                check(job);time.sleep(.25)
            if p.returncode:raise RuntimeError('No se pudo procesar el video o su audio. Prueba otro archivo.')
        finally:
            if p.poll() is None:
                p.terminate()
                try:p.wait(timeout=5)
                except subprocess.TimeoutExpired:p.kill();p.wait()
            with LOCK:PROCESSES.get(job,set()).discard(p)
    check(job)

def probe(path):
    r=subprocess.run(['ffprobe','-v','error','-show_format','-show_streams','-of','json',str(path)],capture_output=True,timeout=30)
    if r.returncode:raise ValueError('No se pudo leer el archivo de video.')
    data=json.loads(r.stdout)
    if not any(s['codec_type']=='video' for s in data['streams']):raise ValueError('El archivo no contiene video.')
    if not any(s['codec_type']=='audio' for s in data['streams']):raise ValueError('Este análisis necesita voz o audio en el video.')
    duration=float(data['format'].get('duration',0))
    if duration<=0:raise ValueError('No se pudo leer la duración.')
    return duration

def resolve(job,url,live=False):
    import yt_dlp
    def hook(d):
        check(job);disk_check()
        if d.get('status')=='downloading':
            size=d.get('total_bytes') or d.get('total_bytes_estimate')
            pct=f"{min(100,100*d.get('downloaded_bytes',0)/size):.0f} %" if size else ''
            update(job,message='Importando video '+pct)
    opts={'quiet':True,'no_warnings':True,'noplaylist':True,'socket_timeout':20,'retries':2,'format':'b[height<=720]/b','outtmpl':str(DATA/job/'source.%(ext)s'),'progress_hooks':[hook],'js_runtimes':{'deno':{}},'max_filesize':2*1024**3}
    with yt_dlp.YoutubeDL(opts) as ydl:
        info=ydl.extract_info(validate_url(url),download=False)
        check(job)
        if info.get('_type') in ('playlist','multi_video'):raise ValueError('Usa el enlace de un solo video o directo.')
        if live:
            if not info.get('is_live'):raise ValueError('El enlace no corresponde a una transmisión en curso. Usa la opción Video grabado.')
            source=info.get('url','')
            if not source.startswith('https://'):raise ValueError('Esta plataforma no ofrece una fuente compatible para este directo.')
            return source
        if info.get('is_live'):raise ValueError('Este enlace está en vivo. Usa la opción Directo en curso.')
        if (info.get('duration') or 0)>MAX_SECONDS:raise ValueError('El video supera el límite de dos horas de esta versión.')
        ydl.download([url]);check(job)
    candidates=[p for p in (DATA/job).glob('source.*') if p.suffix in ('.mp4','.webm','.mkv','.mov')]
    if not candidates:raise ValueError('No se obtuvo un archivo compatible. Prueba subir el video.')
    return candidates[0]

def model():
    global MODEL
    if MODEL is None:
        from faster_whisper import WhisperModel
        MODEL=WhisperModel(os.getenv('WHISPER_MODEL','small'),device='cpu',compute_type='int8',cpu_threads=int(os.getenv('CPU_THREADS','4')),download_root=str(DATA/'models'))
    return MODEL

def transcribe(job,source,settings):
    duration=probe(source)
    if duration>MAX_SECONDS:raise ValueError('El video supera el límite de dos horas.')
    rows=[]
    update(job,message='Preparando transcripción. La primera ejecución descarga el modelo de voz.')
    speech=model()
    for offset in range(0,int(duration)+1,300):
        if offset>=duration:break
        check(job);wav=DATA/job/'audio.wav'
        execute(job,['ffmpeg','-hide_banner','-loglevel','error','-y','-ss',str(offset),'-i',str(source),'-t',str(min(300,duration-offset)),'-vn','-ar','16000','-ac','1',str(wav)])
        update(job,message=f'Transcribiendo voz: minuto {offset//60+1} de {max(1,int(duration/60)+1)}')
        segments,_=speech.transcribe(str(wav),language=None if settings.language=='auto' else settings.language,vad_filter=True,beam_size=3,word_timestamps=False)
        for seg in segments:
            check(job)
            if seg.no_speech_prob<.75 and seg.text.strip():rows.append({'start':seg.start+offset,'end':min(duration,seg.end+offset),'text':seg.text.strip()})
        wav.unlink(missing_ok=True)
    return rows,duration

def stamp(s):
    v=round(max(0,s)*1000);return f'{v//3600000:02}:{v//60000%60:02}:{v//1000%60:02},{v%1000:03}'

def render(job,source,candidate,segments,settings,global_offset=0):
    import textwrap
    folder=DATA/job;clipid=uuid.uuid4().hex;work=folder/clipid;work.mkdir()
    start=candidate['start'];end=candidate['end'];out=folder/(clipid+'.mp4')
    try:
        (work/'title.txt').write_text('\n'.join(textwrap.wrap(candidate['title'],25)),encoding='utf-8')
        (work/'context.txt').write_text('\n'.join(textwrap.wrap(settings.context,27)),encoding='utf-8')
        cues=[]
        for s in segments:
            if s['end']<=start or s['start']>=end:continue
            cues.append(f"{len(cues)+1}\n{stamp(max(0,s['start']-start))} --> {stamp(min(end,s['end'])-start)}\n{s['text']}")
        (work/'subs.srt').write_text('\n\n'.join(cues),encoding='utf-8')
        layout='scale=720:1280:force_original_aspect_ratio=increase,crop=720:1280,setsar=1' if settings.fit=='cover' else 'scale=720:1280:force_original_aspect_ratio=decrease,pad=720:1280:(ow-iw)/2:(oh-ih)/2:black,setsar=1'
        font='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
        filters=[layout,f'drawtext=fontfile={font}:textfile=title.txt:expansion=none:fontsize=38:fontcolor=white:x=(w-text_w)/2:y=110:box=1:boxcolor=black@0.65:boxborderw=12']
        if settings.context:filters.append(f'drawtext=fontfile={font}:textfile=context.txt:expansion=none:fontsize=32:fontcolor=0xc5f56b:x=(w-text_w)/2:y=820:box=1:boxcolor=black@0.65:boxborderw=10')
        if cues:filters.append("subtitles=subs.srt:force_style='FontSize=18,MarginV=40,Outline=2'")
        execute(job,['ffmpeg','-hide_banner','-loglevel','error','-y','-ss',str(start),'-i',str(source),'-t',str(end-start),'-vf',','.join(filters),'-map','0:v:0','-map','0:a:0?','-c:v','libx264','-threads',os.getenv('CPU_THREADS','4'),'-preset','veryfast','-crf','22','-pix_fmt','yuv420p','-c:a','aac','-b:a','128k','-movflags','+faststart',str(out)],cwd=work)
        row={'id':clipid,'title':candidate['title'],'start':round(start+global_offset,2),'end':round(end+global_offset,2),'reason':candidate['reason'],'duration':round(end-start,2)}
        with LOCK:
            clips=json.loads(record(job)['clips']);clips.append(row);update(job,clips=json.dumps(clips))
    except Exception:out.unlink(missing_ok=True);raise
    finally:shutil.rmtree(work,ignore_errors=True)

def process_source(job,source,settings,offset=0):
    rows,duration=transcribe(job,source,settings)
    (DATA/job/'transcript.json').write_text(json.dumps(rows,ensure_ascii=False),encoding='utf-8')
    done=len(json.loads(record(job)['clips']))
    candidates=choose(rows,settings.count-done,settings.min_seconds,settings.max_seconds)
    for i,c in enumerate(candidates):
        check(job);disk_check();c['end']=min(c['end'],duration)
        update(job,message=f'Editando clip {done+i+1} de hasta {settings.count}')
        render(job,source,c,rows,settings,offset)
    return len(candidates)

def live_capture(job,settings):
    update(job,message='Conectando con el directo. La compatibilidad depende de la plataforma.')
    stream=resolve(job,settings.url,live=True);folder=DATA/job/'live';folder.mkdir()
    logpath=folder/'capture.log'
    with logpath.open('wb') as err:
        args=['ffmpeg','-hide_banner','-loglevel','error','-y','-rw_timeout','30000000','-i',stream,'-t',str(settings.live_minutes*60),'-map','0:v:0','-map','0:a:0?','-vf','scale=-2:720','-c:v','libx264','-threads','2','-preset','veryfast','-crf','25','-force_key_frames','expr:gte(t,n_forced*120)','-c:a','aac','-f','segment','-segment_time','120','-reset_timestamps','1',str(folder/'part-%05d.mp4')]
        capture=subprocess.Popen(args,stdout=subprocess.DEVNULL,stderr=err)
        with LOCK:PROCESSES.setdefault(job,set()).add(capture)
        processed=set();offset=0
        try:
            while True:
                check(job);disk_check()
                parts=sorted(folder.glob('part-*.mp4'))
                complete=parts if capture.poll() is not None else parts[:-1]
                waiting=[p for p in complete if p.name not in processed]
                if waiting:
                    p=waiting[0];duration=probe(p)
                    process_source(job,p,settings,offset);offset+=duration;processed.add(p.name);p.unlink(missing_ok=True)
                    if len(json.loads(record(job)['clips']))>=settings.count:break
                    continue
                if capture.poll() is not None:
                    if capture.returncode:raise ValueError('La transmisión se interrumpió o el enlace fue rechazado. Los clips ya terminados se conservan.')
                    break
                update(job,message='Capturando el directo. El primer bloque necesita aproximadamente dos minutos; el análisis añade tiempo.')
                time.sleep(2)
        finally:
            if capture.poll() is None:
                capture.terminate()
                try:capture.wait(timeout=8)
                except subprocess.TimeoutExpired:capture.kill();capture.wait()
            with LOCK:PROCESSES.get(job,set()).discard(capture)
            shutil.rmtree(folder,ignore_errors=True)

def worker(job,uploaded=None):
    try:
        check(job);settings=Settings.model_validate_json(record(job)['settings']);update(job,state='running',message='Preparando tarea en el servidor')
        if settings.mode=='live':live_capture(job,settings)
        else:
            source=uploaded or resolve(job,settings.url)
            process_source(job,source,settings)
            source.unlink(missing_ok=True)
        count=len(json.loads(record(job)['clips']));check(job)
        update(job,state='done',message=f'{count} clips creados. Revisa el contexto y los subtítulos.' if count else 'No se encontraron fragmentos con suficiente voz y duración. Prueba reducir la duración mínima o usar otro video.')
    except InterruptedError:update(job,state='cancelled',message='Tarea detenida. Los clips completados se conservan.')
    except Exception as exc:
        log.exception('Job %s failed',job)
        safe=str(exc) if isinstance(exc,ValueError) else 'No se pudo completar el procesamiento. La fuente puede estar restringida o el servidor no tener recursos suficientes. Prueba subir el archivo o revisar el servicio.'
        update(job,state='error',message=safe[:500])
    finally:
        # Remove source and intermediate data, retaining only completed output files.
        keep={c['id']+'.mp4' for c in json.loads(record(job)['clips'])}
        for p in (DATA/job).iterdir():
            if p.name in keep:continue
            if p.is_dir():shutil.rmtree(p,ignore_errors=True)
            else:p.unlink(missing_ok=True)
        with LOCK:STOP.pop(job,None);PROCESSES.pop(job,None)

@asynccontextmanager
async def lifespan(app):
    if len(KEY)<32:raise RuntimeError('PROCESSOR_API_KEY debe contener al menos 32 caracteres.')
    initialize()
    yield
    for event in list(STOP.values()):event.set()
    for processes in list(PROCESSES.values()):
        for p in list(processes):
            if p.poll() is None:p.terminate()

app=FastAPI(lifespan=lifespan,docs_url=None,redoc_url=None)
@app.get('/health')
def health():return {'ok':True,'version':'1.0','engine':'whisper-small-cpu','live':'experimental'}
@app.get('/jobs')
def jobs(owner=Depends(auth)):
    with connect() as c:rows=c.execute('SELECT * FROM jobs WHERE owner=? ORDER BY created DESC LIMIT 100',(owner,)).fetchall()
    return [expose(dict(r)) for r in rows]
@app.post('/jobs')
def create(settings:Settings,owner=Depends(auth)):
    try:settings.url=validate_url(settings.url)
    except ValueError as exc:raise HTTPException(400,str(exc))
    job=new_job(owner,settings);QUEUE.submit(worker,job);return expose(record(job))
@app.post('/upload')
async def upload(req:Request,owner=Depends(auth)):
    try:settings=Settings.model_validate_json(unquote(req.headers.get('X-Clip-Settings','{}')))
    except ValueError:raise HTTPException(400,'Configuración no válida.')
    settings.mode='video';settings.url='';job=new_job(owner,settings);path=DATA/job/'uploaded.bin';total=0
    update(job,state='uploading',message='Recibiendo archivo')
    try:
        with path.open('wb') as f:
            async for chunk in req.stream():
                check(job);total+=len(chunk)
                if total>MAX_UPLOAD:raise HTTPException(413,'Máximo 80 MB por archivo. Para videos grandes usa un enlace.')
                f.write(chunk)
        if total==0:raise HTTPException(400,'El archivo está vacío.')
        update(job,state='queued',message='Archivo recibido. En cola');QUEUE.submit(worker,job,path);return expose(record(job))
    except BaseException:
        path.unlink(missing_ok=True);update(job,state='error',message='La carga fue interrumpida o supera 80 MB.');STOP.pop(job,None);raise
@app.get('/jobs/{job}')
def get_job(job:str,owner=Depends(auth)):return expose(owned(job,owner))
@app.post('/jobs/{job}/stop')
def stop(job:str,owner=Depends(auth)):
    row=owned(job,owner)
    if row['state'] in TERMINAL:return expose(row)
    if job in STOP:STOP[job].set()
    update(job,message='Deteniendo tarea…');return expose(record(job))
@app.delete('/jobs/{job}')
def delete(job:str,owner=Depends(auth)):
    row=owned(job,owner)
    if row['state'] not in TERMINAL:raise HTTPException(409,'Detén la tarea y espera a que termine antes de eliminarla.')
    shutil.rmtree(DATA/job,ignore_errors=True)
    with connect() as c:c.execute('DELETE FROM jobs WHERE id=? AND owner=?',(job,owner))
    return {'deleted':True}
@app.get('/jobs/{job}/clips/{clip}')
def media(job:str,clip:str,download:bool=False,owner=Depends(auth)):
    row=owned(job,owner)
    if not any(c['id']==clip for c in json.loads(row['clips'])):raise HTTPException(404,'Clip no encontrado.')
    path=DATA/job/(clip+'.mp4')
    if not path.exists():raise HTTPException(404,'El archivo ya no está disponible.')
    return FileResponse(path,media_type='video/mp4',filename=clip+'.mp4' if download else None,content_disposition_type='attachment' if download else 'inline')
