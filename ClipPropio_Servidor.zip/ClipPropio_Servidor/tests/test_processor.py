import os,sys,json,subprocess,threading
from pathlib import Path
import pytest
os.environ['PROCESSOR_API_KEY']='test-secret-not-for-production-0000000000'
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import main as m
from selection import choose
from fastapi.testclient import TestClient

@pytest.fixture
def env(tmp_path,monkeypatch):
 monkeypatch.setattr(m,'DATA',tmp_path);monkeypatch.setattr(m,'DB',tmp_path/'jobs.sqlite');m.STOP.clear();m.PROCESSES.clear();m.initialize()
 return tmp_path

def headers(owner='one'):
 return {'Authorization':'Bearer '+m.KEY,'X-Clip-Owner':owner}

def segments():
 return [{'start':i*6,'end':i*6+5.7,'text':('Pero descubrí la verdad y este error cambió toda la historia. ' if i%6==0 else 'Esta es una frase completa con suficientes palabras para contar la historia. ')+str(i)+'.'} for i in range(40)]

def test_selection():
 spans=choose(segments(),5,30,60)
 assert 1<len(spans)<=5
 assert all(29.9<=c['end']-c['start']<=60.3 for c in spans)
 assert all(a['end']<=b['start']+1 for a,b in zip(spans,spans[1:]))
 assert not choose([],5,30,60)
 assert not choose([{'start':0,'end':2,'text':'Hola.'}],5,30,60)

def test_url_validation():
 for url in ['https://www.youtube.com/watch?v=test','https://www.twitch.tv/example','https://www.facebook.com/watch/?v=123','https://www.tiktok.com/@a/video/123']:assert m.validate_url(url)==url
 for url in ['http://localhost:3000','https://youtube.com.evil.test/a','file:///etc/passwd','https://evil.test','https://user:pass@youtube.com/a']:
  with pytest.raises(ValueError):m.validate_url(url)

def test_schema():
 with pytest.raises(ValueError):m.Settings(count=50)
 with pytest.raises(ValueError):m.Settings(min_seconds=90,max_seconds=30)
 with pytest.raises(ValueError):m.Settings(mode='anything')

def test_access_and_lifecycle(env):
 with TestClient(m.app) as client:
  assert client.get('/jobs').status_code==401
  owner=m.hashlib.sha256(b'one').hexdigest();job=m.new_job(owner,m.Settings())
  assert client.get('/jobs/'+job,headers=headers('two')).status_code==404
  assert client.get('/jobs/'+job,headers=headers()).status_code==200
  assert client.delete('/jobs/'+job,headers=headers()).status_code==409
  assert client.post('/jobs/'+job+'/stop',headers=headers()).status_code==200
  assert m.STOP[job].is_set()
  m.update(job,state='done',message='test')
  assert client.delete('/jobs/'+job,headers=headers()).status_code==200
  assert client.get('/jobs/'+job,headers=headers()).status_code==404

def test_restart_marks_pending(env):
 job=m.new_job('owner',m.Settings());m.initialize();assert m.record(job)['state']=='error'

def test_render_multiple_mp4_and_range(env):
 source=env/'source.mp4'
 subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','lavfi','-i','testsrc2=size=640x360:rate=24','-f','lavfi','-i','sine=frequency=440:sample_rate=48000','-t','4','-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac',str(source)],check=True)
 owner=m.hashlib.sha256(b'one').hexdigest();job=m.new_job(owner,m.Settings())
 rows=[{'start':0,'end':4,'text':'Subtítulo de prueba.'}]
 for a,b in [(0,1.5),(2,3.5)]:m.render(job,source,{'start':a,'end':b,'title':"Mamá dijo: 100% real",'reason':'Prueba de exportación'},rows,m.Settings(context='Mi opinión personal',fit='contain'))
 clips=json.loads(m.record(job)['clips']);assert len(clips)==2
 p=env/job/(clips[0]['id']+'.mp4')
 data=json.loads(subprocess.check_output(['ffprobe','-v','quiet','-show_streams','-of','json',str(p)]))
 video=next(s for s in data['streams'] if s['codec_type']=='video');assert (video['width'],video['height'])==(720,1280)
 assert any(s['codec_type']=='audio' for s in data['streams'])
 with TestClient(m.app) as client:
  url='/jobs/'+job+'/clips/'+clips[0]['id']
  r=client.get(url,headers={**headers(),'Range':'bytes=0-99'});assert r.status_code==206;assert len(r.content)==100
  assert client.get(url,headers=headers('two')).status_code==404

def test_upload_size_cleanup(env,monkeypatch):
 monkeypatch.setattr(m,'MAX_UPLOAD',10)
 with TestClient(m.app) as client:
  response=client.post('/upload',content=b'a'*11,headers=headers())
  assert response.status_code==413
  jobs=client.get('/jobs',headers=headers()).json();assert jobs[0]['state']=='error'
  assert not list(env.glob('*/uploaded.bin'))
