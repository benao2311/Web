# Clip Propio · procesador en servidor

Este servicio necesita alojamiento propio. Publicar la interfaz en Sites NO
activa el procesamiento. No hay pagos ni cuentas creados automáticamente.

## Despliegue

Desplegar la carpeta `processor` como servicio Docker Linux con:
- Como punto inicial: 4 vCPU y 4 GB RAM; validar con videos reales antes de prometer tiempo real.
- Un disco persistente montado en `/data` (modelos, SQLite y clips). Empezar con 25 GB.
- Un solo proceso Uvicorn, una sola réplica. El trabajador procesa una tarea a la vez.
- `PROCESSOR_API_KEY`: secreto aleatorio de al menos 32 caracteres; generarlo en el proveedor.
- `DATA_DIR=/data`, `CPU_THREADS=4`, `WHISPER_MODEL=small`.
- Puerto HTTP mediante `PORT` y verificación de salud `/health`.
- Salida a internet para descargar modelos Hugging Face y acceder a plataformas.
- TLS público para que la interfaz pueda conectarse al servicio.

Después configurar en Sites, como secretos de servidor:
`CLIP_PROCESSOR_URL=https://URL-DEL-SERVICIO`
`CLIP_PROCESSOR_KEY` con el mismo valor de `PROCESSOR_API_KEY`.
Publicar una nueva versión de la interfaz después de configurarlos.
Nunca colocar la clave en el navegador ni en Git.

## Funciones y límites

Videos: enlaces públicos individuales de YouTube/Twitch/Facebook/TikTok, sujetos
al soporte de yt-dlp y a restricciones de la plataforma. No se inicia sesión,
no se leen cookies ni se garantizan todos los enlaces. Importación por enlace
limitada a 2 horas y 2 GB; subida por la web hasta 80 MB.

Transcripción por IA con Whisper. Selección editorial por continuidad de voz,
frases completas, diversidad y señales de interés en el texto. No es un modelo
que prediga viralidad. Puede entregar menos clips que los solicitados o ninguno.
Exportación MP4 720×1280, audio, título extraído del discurso y subtítulos.
No incluye seguimiento facial ni análisis visual de escenas.

Directos: experimental. Resolver una fuente accesible, capturar continuamente
hasta 60 minutos y analizar bloques cerrados de unos dos minutos mientras
continúa la captura. Puede perder contexto entre bloques y acumular retraso.
No analiza chat. Una interrupción conserva los clips ya terminados. No se
reconecta automáticamente ni evade restricciones del proveedor.

Los usuarios del Site se aíslan con el ID verificado por Sites y un secreto entre
servidores. No exponer el procesador con una clave débil ni añadir CORS público.
El servidor conserva los archivos hasta que el usuario elimine la tarea; cuota
local por instancia de 20 GB por defecto. La web permite borrar solo tareas
terminadas con confirmación. Los reinicios marcan tareas pendientes como
interrumpidas. Copiar /data para respaldos. Esto es una versión de un solo servidor.

## Activación y validación pendiente

Antes de activar: conectar un proveedor o servidor propio, verificar su plan/precio,
aprobar el gasto concreto, desplegar el contenedor, configurar secretos y probar
un video real autorizado. La prueba de Docker, descarga del modelo, importación
externa y captura de directos depende de ese entorno. Los tests con transcripciones
sintéticas verifican algoritmos y exportación, no calidad editorial real.

## Pruebas

`pip install -r requirements.txt pytest httpx`
`PROCESSOR_API_KEY=clave-de-prueba-de-al-menos-32-caracteres pytest tests -q`

Fuentes: https://github.com/SYSTRAN/faster-whisper,
https://github.com/yt-dlp/yt-dlp, https://render.com/docs/docker,
https://render.com/docs/disks
