"""Rank transcript spans; scores are editorial heuristics, not viral predictions."""
import math, re
HOOKS=re.compile(r'\b(pero|nunca|nadie|secreto|verdad|error|increíble|imagina|resulta|descubrí|por qué|cómo|ojo|cuidado|problema|solución|but|never|secret|mistake|why|how)\b',re.I)
STOP=set('de la el en un una y que es a lo los las por para con del se me te mi yo tu su al o no si the and to of in is it you i'.split())
def terms(text):return set(re.findall(r'\w+',text.lower()))-STOP

def choose(segments,count=5,min_seconds=30,max_seconds=75):
    candidates=[]
    for i,s in enumerate(segments):
        if len(s['text'].strip())<8:continue
        # Prefer a sentence or pause boundary rather than mid-sentence.
        if i and s['start']-segments[i-1]['end']<.4 and not re.search(r'[.!?…]$',segments[i-1]['text'].strip()):continue
        span=[]
        for e in segments[i:]:
            if e['end']-s['start']>max_seconds:break
            span.append(e)
            duration=e['end']-s['start']
            if duration<min_seconds:continue
            text=' '.join(x['text'].strip() for x in span)
            words=re.findall(r'\w+',text)
            if len(words)<25:continue
            speech=sum(max(0,x['end']-x['start']) for x in span)/duration
            if speech<.45:continue
            score=min(6,len(HOOKS.findall(text)))*1.5+min(3,len(re.findall(r'[!?¿¡]',text)))*.65
            score+=len(terms(text))/max(1,len(words))*3+min(speech,1)*2
            if re.search(r'[.!?…]$',e['text'].strip()):score+=2
            score+=min(duration,60)/60
            title=re.sub(r'\s+',' ',s['text'].strip())
            if len(title)>75:title=title[:72].rsplit(' ',1)[0]+'…'
            candidates.append(dict(start=max(0,s['start']-.15),end=e['end']+.1,title=title,text=text,score=round(score,2),reason='Fragmento con continuidad de voz y señales de interés en la transcripción.'))
    chosen=[]
    for c in sorted(candidates,key=lambda c:c['score'],reverse=True):
        overlap=lambda p:max(0,min(c['end'],p['end'])-max(c['start'],p['start']))
        if any(overlap(p)>1 for p in chosen):continue
        ct=terms(c['text'])
        if any(len(ct&terms(p['text']))/max(1,len(ct|terms(p['text'])))>.72 for p in chosen):continue
        chosen.append(c)
        if len(chosen)>=count:break
    return sorted(chosen,key=lambda c:c['start'])
